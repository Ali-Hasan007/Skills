﻿# Codex Skills

Personal Codex skill pack exported from C:\Users\HP\.codex\skills.

## Install

Copy the folders inside `skills/` into your Codex skills directory:

```text
C:\Users\<you>\.codex\skills
```

Restart Codex after copying so it can discover the new skills.

## Included Skills

- algorithmic-art
- brand-guidelines
- canvas-design
- doc-coauthoring
- docx
- frontend-design
- internal-comms
- mcp-builder
- pdf
- pptx
- skill-creator
- slack-gif-creator
- theme-factory
- webapp-testing
- web-artifacts-builder
- xlsx
